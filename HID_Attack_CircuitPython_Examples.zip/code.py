# Write your code here :-)
## Wi-Fi Nugget HID Attack Example, With OLED indicator

import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
from adafruit_hid.keycode import Keycode
from digitalio import DigitalInOut, Direction, Pull
from board import SCL, SDA
import board
import busio
import displayio
import adafruit_framebuf
import adafruit_displayio_sh1106
import time
import neopixel

pixel_pin = board.IO12    # Specify the pin that the neopixel is connected to (GPIO 12)
num_pixels = 1  # Set number of neopixels
pixel = neopixel.NeoPixel(pixel_pin, num_pixels, brightness=0.01)   # Create neopixel and set brightness to 30%

def SetAll(color):   # Define function with one input (color we want to set)
    for i in range(0, num_pixels):   # Addressing all 11 neopixels in a loop
        pixel[i] = (color)   # Set all neopixels a color

kbd = Keyboard(usb_hid.devices)
layout = KeyboardLayoutUS(kbd)

displayio.release_displays()
WIDTH = 130 # Change these to the right size for your display!
HEIGHT = 64
BORDER = 1
i2c = busio.I2C(SCL, SDA) # Create the I2C interface.
display_bus = displayio.I2CDisplay(i2c, device_address=0x3c)
display = adafruit_displayio_sh1106.SH1106(display_bus, width=WIDTH, height=HEIGHT) # Create the SH1106 OLED class.

def NugEyes(IMAGE): ## Make a function to put eyes on the screen
    bitmap = displayio.OnDiskBitmap(IMAGE) # Setup the file as the bitmap data source
    tile_grid = displayio.TileGrid(bitmap, pixel_shader=bitmap.pixel_shader) # Create a TileGrid to hold the bitmap
    group = displayio.Group() # Create a Group to hold the TileGrid
    group.append(tile_grid) # Add the TileGrid to the Group
    display.show(group) # Add the Group to the Display

def MacOSPayload():
    SetAll([255,0,0])
    NugEyes("/faces/boingo.bmp")
    kbd.send(Keycode.GUI, Keycode.SPACE), time.sleep(.5)
    layout.write('terminal.app\n'), time.sleep(1)
    layout.write('curl parrot.live\n')


MacOSPayload()
SetAll([0,255,0])
while True:
    NugEyes("/faces/uwu.bmp")
