# Simple CircuitPython Mouse Jiggler, by @KodyKinzie for Hack.gay & Retia.io using Adafruit CircuitPython
# Objective: Create an HID device which will prevent a computer from going to sleep
import usb_hid
from adafruit_hid.mouse import Mouse
import time
import random
minDelay = 1; maxDelay = 15 ## What is the minimum and maximum delay?
JitterFactor = 10 ## How far do we move the mouse?
baseline = time.monotonic() ## Take a baseline time measurement to compare later

def getRandomTime(): ## Returns a random time delay between our minimum and maximum possible
    return (random.randint(minDelay, maxDelay))

m = Mouse(usb_hid.devices) ## Create the mouse object
timeInterval = getRandomTime() ## Grab a random interval from our minimum to maximum possible delay

while True:
    if (time.monotonic() - baseline) > timeInterval: ## Check if the time is past our random delay
        print('Boop')
        m.move(x=-JitterFactor, y=-JitterFactor) ## Move the mose up and to the left
        m.move(x=JitterFactor, y=JitterFactor) ## Move the mouse back down and to the right real quick
        baseline = time.monotonic() ## Reset our timer for the next delay
        timeInterval = random.randint(minDelay, maxDelay) ## Pick a new random time interval
        print('going again in', timeInterval)
