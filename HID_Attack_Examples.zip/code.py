# The Nugget Jiggler, by @KodyKinzie for Hack.gay & Retia.io using Adafruit CircuitPython
# Objective: Create an HID device which will prevent a computer from going to sleep
# MVP: Jiggles randomly when plugged in, jiggling animation on screen
# Key stretch goals: Start and stop with button. Configure duration between random movements from buttons. On-screen display.

import usb_hid
from adafruit_hid.mouse import Mouse
import time
import random
import board
import neopixel
from digitalio import DigitalInOut, Direction, Pull
from board import SCL, SDA
import busio
import displayio
import adafruit_framebuf
import adafruit_displayio_sh1106

## Screen setup and function to change image on the screen

displayio.release_displays()
WIDTH = 130 # Change these to the right size for your display!
HEIGHT = 64
BORDER = 1

i2c = busio.I2C(SCL, SDA) # Create the I2C interface.
display_bus = displayio.I2CDisplay(i2c, device_address=0x3c)
display = adafruit_displayio_sh1106.SH1106(display_bus, width=WIDTH, height=HEIGHT) # Create the SH1106 OLED class.

def NugEyes(IMAGE): ## Make a function to put eyes on the screen
    bitmap = displayio.OnDiskBitmap(IMAGE) # Setup the file as the bitmap data source
    tile_grid = displayio.TileGrid(bitmap, pixel_shader=bitmap.pixel_shader) # Create a TileGrid to hold the bitmap
    group = displayio.Group() # Create a Group to hold the TileGrid
    group.append(tile_grid) # Add the TileGrid to the Group
    display.show(group) # Add the Group to the Display

NugEyes("/faces/mouse.bmp") #@# Show menu
## Mouse Setup

m = Mouse(usb_hid.devices)

## Neopixel Setup

pixel_pin = board.IO12    # Specify the pin that the neopixel is connected to (GPIO 12)
num_pixels = 1; delay = .1   # Set number of neopixels & delay between color changes in seconds
pixel = neopixel.NeoPixel(pixel_pin, num_pixels, brightness=0.3)   # Create neopixel and set brightness to 30%

def SetAll(color):   # Define function with one input (color we want to set)
    for i in range(0, num_pixels):   # Addressing all 1 neopixels in a loop
        pixel[i] = (color)   # Set all neopixels a color

"""
This script relies on an example which shows how to read button state with
debouncing that does not rely on time.sleep().
"""

## Button Setup

#ButtonDict = {'up': 'IO9', 'down': 'IO18', 'left': 'IO11', 'right': 'IO14'} man these suck to use for indexing what was I thinking
LabelList = ['up', 'down', 'left', 'right']
PinList = ['IO9', 'IO18', 'IO11', 'IO14']

upBtn = DigitalInOut(board.IO9)
upBtn.direction = Direction.INPUT
upBtn.pull = Pull.UP
up_prev_state = upBtn.value

downBtn = DigitalInOut(board.IO18)
downBtn.direction = Direction.INPUT
downBtn.pull = Pull.UP
down_prev_state = downBtn.value

leftBtn = DigitalInOut(board.IO11)
leftBtn.direction = Direction.INPUT
leftBtn.pull = Pull.UP
left_prev_state = leftBtn.value

rightBtn = DigitalInOut(board.IO7)
rightBtn.direction = Direction.INPUT
rightBtn.pull = Pull.UP
right_prev_state = rightBtn.value

## Set up variables to check on the state of buttons and see if they have been pressed

ButtonList = [upBtn, downBtn, leftBtn, rightBtn]
StateList = [up_prev_state, down_prev_state, left_prev_state, right_prev_state]


def jiggleMouse(pressedValue):
    if pressedValue == 0:
        WeJiggling = False
        NugEyes("/faces/uwu.bmp")
        SetAll([0,255,0])
    if pressedValue == 1:
        WeJiggling = False
        NugEyes("/faces/uwu.bmp")
        SetAll([0,255,0])
    if pressedValue == 2:
        WeJiggling = False
        NugEyes("/faces/uwu.bmp")
        SetAll([0,255,0])
    if pressedValue == 3:
        WeJiggling = True
        NugEyes("/faces/boingo.bmp")
        SetAll([255,0,0])
    return(WeJiggling)

WeJiggling = False ## Tell me, are we jiggling?
JiggleFactor = 150 ## Out of what number do we pick a random chance for a jiggle? Example: 1/100 jiggles several times per second. 1/200 takes longer.
JitterFactor = 10 ## How far do we move the mouse?
JigglingNug = ["/faces/j1.bmp", "/faces/j2.bmp", "/faces/j3.bmp", "/faces/j4.bmp", "/faces/j5.bmp", "/faces/j6.bmp", "/faces/j7.bmp", "/faces/j8.bmp"] ## Jiggling mouse for an animation

while True:
    for i in range(4):
        cur_state = ButtonList[i].value
        if cur_state != StateList[i]:
            if not cur_state:
                print(LabelList[i], "is pressed")
                try: WeJiggling = jiggleMouse(i)
                except TypeError:
                    print("wut")
            else:
                print(LabelList[i],"is released")
                SetAll([0,0,0])
        StateList[i] = cur_state
        if WeJiggling:
            for i in range(len(JigglingNug)):
                if random.randint(0,JiggleFactor) == 1:
                    SetAll([0,0,255])
                    NugEyes("/faces/boingo.bmp")
                    m.move(x=-JitterFactor, y=-JitterFactor)
                    m.move(x=JitterFactor, y=JitterFactor)
                    SetAll([255,0,0])
                NugEyes(JigglingNug[i])

