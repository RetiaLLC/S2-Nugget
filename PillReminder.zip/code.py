# SPDX-FileCopyrightText: 2020 Brent Rubell for Adafruit Industries
#
# SPDX-License-Identifier: MIT

import ipaddress
import ssl
import wifi
import socketpool
import adafruit_requests
import displayio
import os
import board
import neopixel
from board import SCL, SDA
import busio
import displayio
import adafruit_framebuf
import adafruit_displayio_sh1106
import time
import terminalio
from adafruit_display_text import label
from adafruit_ntp import NTP
from digitalio import DigitalInOut
import rtc
import storage
from digitalio import DigitalInOut, Pull
import circuitpython_csv as csv
from adafruit_debouncer import Debouncer

pins = (board.IO9, board.IO18, board.IO11, board.IO7)
buttons = []   # will hold list of Debouncer objects
for pin in pins:   # set up each pin
    tmp_pin = DigitalInOut(pin) # defaults to input
    tmp_pin.pull = Pull.UP      # turn on internal pull-up resistor
    buttons.append(Debouncer(tmp_pin))

displayio.release_displays()
WIDTH = 130 # Change these to the right size for your display!
HEIGHT = 64
BORDER = 0
i2c = busio.I2C(SCL, SDA) # Create the I2C interface.
display_bus = displayio.I2CDisplay(i2c, device_address=0x3c)
display = adafruit_displayio_sh1106.SH1106(display_bus, width=WIDTH, height=HEIGHT) # Create the SH1106 OLED class.

#qr_img = displayio.TileGrid(qr_bitmap, pixel_shader=palette, x=pos_x, y=pos_y)


# Get wifi details and more from a secrets.py file
try:
    from secrets import secrets
except ImportError:
    print("WiFi secrets are kept in secrets.py, please add them there!")
    raise

wifi.radio.connect(secrets["ssid"], secrets["password"])
print("Connected to Wi-Fi")
print("My IP address is", wifi.radio.ipv4_address)

ipv4 = ipaddress.ip_address("8.8.4.4")
print("Ping google.com: %f ms" % (wifi.radio.ping(ipv4)*1000))

pool = socketpool.SocketPool(wifi.radio)
requests = adafruit_requests.Session(pool, ssl.create_default_context())


radio = wifi.radio
pool = socketpool.SocketPool(radio)
requests = adafruit_requests.Session(pool, ssl.create_default_context())
## Make sure to change the time zone to match yours in the API request below: GMT-6 is Mountian Time
def SetTime():
    response = requests.get("http://worldtimeapi.org/api/timezone/Etc/GMT-6")
    localtime = (int(response.json()['unixtime']) - int(response.json()['raw_offset']))

    if response.status_code == 200:
        r = rtc.RTC()
        r.datetime = time.localtime(localtime)
        print(f"System Time: {r.datetime}")
        return r
    else:
        print("Setting time failed")

def WriteTime():
    r = SetTime()
    all_files = os.listdir()
    if "timelog.csv" not in all_files:
        with open("timelog.csv", mode="w", encoding="utf-8") as writablefile:
            csvwriter = csv.writer(writablefile)
            csvwriter.writerow(["Year", "Month", "Day", "Hour", "Minuite"])
            csvwriter.writerow([r.datetime.tm_year, r.datetime.tm_mon, r.datetime.tm_mday, r.datetime.tm_hour, r.datetime.tm_min])
    else:
        with open("timelog.csv", mode="a", encoding="utf-8") as writablefile:
            csvwriter = csv.writer(writablefile)
            csvwriter.writerow([r.datetime.tm_year, r.datetime.tm_mon, r.datetime.tm_mday, r.datetime.tm_hour, r.datetime.tm_min])
    DisplayUpdate(ReadLast())

def ReadLast():
    try:
        with open("timelog.csv", "r") as file:
            data = file.readlines()
            try: lastRow = data[-1]
            except: lastRow = 0
            print(lastRow)
            print(data)
            return(lastRow)
    except: print("No Data")

def choosy(pin):
    if pin == 0:
        SetTime()
        try: WriteTime()
        except OSError: print("Whoopsi")
    if pin == 2:
        ReadLast()
    else: print("No")

def DisplayUpdate(lastRow):
    try:
        datas = lastRow.split(',')
    except:
        datas = ["Year", "Month", "Day", "Hour", "Minuite"]
    text = "Last Dose: {}/{}/{}".format(datas[1], datas[2], datas[0])
    splash = displayio.Group(scale=1)
    line2 = "Taken At: {}:{}".format(datas[3], datas[4])
    line3 = "Press UP to add dose"

    font = terminalio.FONT
    color = 0xFFFFFF

    text_area = label.Label(font, text=text, color=color)
    second_text = label.Label(font, text=line2, color=color)
    third_text = label.Label(font, text=line3, color=color)

    text_area.x = 0
    text_area.y = 0

    texty = displayio.Group(x=5, y=5, scale=1)
    texty.append(text_area)
    splash.append(texty)

    secondline = displayio.Group(x=5, y=15, scale=1)
    secondline.append(second_text)
    splash.append(secondline)

    thirdline = displayio.Group(x=5, y=35, scale=1)
    thirdline.append(third_text)
    splash.append(thirdline)

    display.show(splash)

r = SetTime()
DisplayUpdate(ReadLast())

while True:
    for i in range(len(buttons)):
        buttons[i].update()
        if buttons[i].fell:
            print("button",i,"pressed!")
            choosy(i)
        if buttons[i].rose:
            print("button",i,"released!")
