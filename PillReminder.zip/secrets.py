secrets = {
    'ssid' : 'test',
    'password' : 'testy',
    'openweather_token' : 'your-openweather-token-here',
    'aio_username' : "your-aio-username-here",
    'aio_key' : 'your-aio-key-here',
    'location' : 'New York, US'
}# Write your code here :-)
